SWATCH — DRAFT
30 authored creative folio pages, nine of fifteen independent primary illustrations are present; six remain missing.
Thirty fictional visual material questions, not tested specimens, specifications or production instructions.
Open index.html directly via file://. Chapter index, three-card comparison tray, text edits, pinned IDs, note and embedded-asset HTML export work without a server.
Local storage can be unavailable; export HTML/JSON to retain changes. Current HTML includes the private note; review it before sharing. Original PDF/PPTX do not change with browser edits and are separate downloads, not bundled here.
Manifest describes original PDF/PPTX as well as source assets. Typographic pending frames are not independent artworks. No participant data or operational approval is supplied.
