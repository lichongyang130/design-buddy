SERVICE ECONOMICS / 商业规划
Ten A4 pages, five distinct illustrations per case. Five curated existing AI-generated illustrations; no new artwork is claimed. Full provenance is included. Repeated placements are not extra images.
Open index.html directly via file://. Navigation, edits, current DOCX/HTML/JSON export run without a server. Long edits may reflow. Review the private note before sharing.
Original PDF/DOCX are separate downloads, not bundled here. Asset manifest also describes those originals. A fictional Review Sessions capacity model. Minutes and teaching credits are illustrative; credits are not currency, prices, revenue or profit, and no actual service, staffing or demand is supplied.
