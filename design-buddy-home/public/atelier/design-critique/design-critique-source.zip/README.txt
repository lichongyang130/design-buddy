DESIGN CRITIQUE / 产品设计
Ten A4 pages, five distinct illustrations per case. Five curated existing AI-generated illustrations; no new artwork is claimed. Full provenance is included. Repeated placements are not extra images.
Open index.html directly via file://. Navigation, edits, current DOCX/HTML/JSON export run without a server. Long edits may reflow. Review the private note before sharing.
Original PDF/DOCX are separate downloads, not bundled here. Asset manifest also describes those originals. An authored critique plan for two fictional Context Card alternatives. The rubric is defined, but all six principle/alternative scores and real reviewer opinions remain unrecorded.
