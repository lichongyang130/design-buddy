TRACTION DIALOGUE / 融资演讲稿
Ten A4 pages, five distinct illustrations per case. One new AI-generated hero, four curated existing AI-generated images; full provenance is included. Repeated placements are not extra images.
Open index.html directly via file://. Navigation, edits, current DOCX/HTML/JSON export run without a server. Long edits may reflow. Review the private note before sharing.
Original PDF/DOCX are separate downloads, not bundled here. Asset manifest also describes those originals. Fictional fundraising speech template. Spoken drafts, ventures, people and illustrative models are invented; no real traction, validated impact, technical performance, securities offer, investment terms or committed funding is supplied.
