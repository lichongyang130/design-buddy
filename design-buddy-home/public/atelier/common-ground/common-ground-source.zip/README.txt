COMMON GROUND — A4 DOCUMENT TEMPLATE
Ten authored document pages and five independent watercolours.
Open index.html directly via file://. Text editing, page contents, current DOCX/HTML/JSON exports work without a server. DOCX uses native paragraphs/headings, embedded JPEGs and explicit page breaks, not screenshots of pages.
Original PDF and DOCX are separate downloads; not duplicated in this source ZIP. Manifest also describes those separate originals.
Current exports include the private note; review it before sharing. Long edits may reflow beyond ten pages in Word.
Fictional garden concept, not a site survey, permissions, funding, construction or operational approval. No sensitive participant information is needed.
