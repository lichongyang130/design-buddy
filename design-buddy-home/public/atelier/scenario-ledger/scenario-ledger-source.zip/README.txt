SCENARIO LEDGER / 商业规划
Ten A4 pages, five distinct illustrations per case. Five curated existing AI-generated illustrations; no new artwork is claimed. Full provenance is included. Repeated placements are not extra images.
Open index.html directly via file://. Navigation, edits, current DOCX/HTML/JSON export run without a server. Long edits may reflow. Review the private note before sharing.
Original PDF/DOCX are separate downloads, not bundled here. Asset manifest also describes those originals. A fictional Edition Table planning model using arbitrary teaching points. Three demand cases share capacity 12; points are not currency, revenue, profit, cash flow or a real forecast.
