TIDELINE — COMPLETE COASTAL MODEL ATLAS
Open index.html directly without a server.
32 authored pages; all 16 independent primary illustrations present. Repeated placements are not extra art.
240 entirely synthetic entry events, not unique visitors or occupancy. No real route, weather, safety or collection advice.
Filter, paginated source ledger and selected CSV work offline. Local storage may be unavailable; export HTML/JSON to retain edits.
Current HTML includes selected chart scope and edits; original PDF/PPTX are separate full-model downloads, not rewritten by browser edits.
The manifest also describes separate PDF/PPTX files that are not bundled in this ZIP.
