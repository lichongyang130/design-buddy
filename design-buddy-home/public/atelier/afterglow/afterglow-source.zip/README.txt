AFTERGLOW — COMPLETE FOLIO
30 authored creative folio pages, all fifteen independent primary illustrations are present.
Five acts and six beats are reading order, not minutes, show calls, a staging plan or a real event schedule.
Open index.html directly via file://. Directory, act/beat navigation, local creative marks, edits, note and embedded-asset HTML export work without a server.
Local storage can be unavailable; export HTML/JSON to retain changes. Current HTML includes the private note; review it before sharing. Original PDF/PPTX do not change with browser edits and are separate downloads, not bundled here.
Manifest describes original PDF/PPTX as well as source assets. Typographic pending frames are not independent artworks. No participant data or operational approval is supplied.
