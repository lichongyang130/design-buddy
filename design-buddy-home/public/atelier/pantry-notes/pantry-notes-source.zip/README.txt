PANTRY NOTES — COMPLETE CASE
Open index.html directly without a server.
32 authored pages; 16 independent main illustrations. No missing main art.
Edits save locally where file-origin storage is available; otherwise use HTML/JSON exports.
Original PDF/PPTX are separate downloads and not rewritten by browser edits.
Fictional arithmetic, not real measurements or cooking/food-safety/calibration advice.
