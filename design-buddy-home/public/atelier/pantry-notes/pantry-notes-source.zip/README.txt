PANTRY NOTES — NEW REBUILD PREVIEW
Open index.html directly without a server.
32 pages; 10 independent main illustrations of 16 planned; six still missing. Context diagrams are not primary art.
Edits save locally where file-origin storage is available; otherwise use HTML/JSON exports.
Original PDF/PPTX are separate downloads and not rewritten by browser edits.
Fictional arithmetic, not real measurements or cooking/food-safety/calibration advice.
