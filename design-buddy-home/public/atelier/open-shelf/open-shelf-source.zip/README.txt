OPEN SHELF — COMPLETE CONCEPT CASE
Open index.html directly without a server.
32 authored boards; 16 independent main illustrations. No primary art is missing.
Review marks and notes are browser-local drafts, not actual approval or a shared team record. Avoid sensitive personal data.
Current HTML/JSON exports retain edits; original PDF/PPTX are separate downloads and remain unchanged.
All scenes, resource numbers and plans are fictional. No construction, access, safety, privacy, procurement or operational approval.
The asset manifest also describes separate original PDF/PPTX files, not bundled in this ZIP.
