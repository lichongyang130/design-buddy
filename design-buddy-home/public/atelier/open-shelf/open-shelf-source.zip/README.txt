OPEN SHELF — IN-PROGRESS CONCEPT PREVIEW
Open index.html directly without a server.
32 authored boards; 10 main illustrations of 16 planned; six still missing. Supporting diagrams are not primary art.
Review marks and notes are browser-local drafts, not actual approval or a shared team record. Avoid sensitive personal data.
Current HTML/JSON exports retain edits; original PDF/PPTX are separate downloads and remain unchanged.
All scenes, resource numbers and plans are fictional. No construction, access, safety, privacy, procurement or operational approval.
The asset manifest also describes separate original PDF/PPTX files, not bundled in this ZIP.
